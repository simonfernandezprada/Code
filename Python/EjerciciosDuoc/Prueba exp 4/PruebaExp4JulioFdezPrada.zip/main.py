import funciones as fn

fn.menu()
