1).- Se requiere crear un vector de tamaño 100, completar los valores del vector aleatoriamente con
números enteros del 0 al 10, para ello deberá investigar la función que permita crear números
aleatorios.
2).- Mostrar por pantalla sólo los valores que se encuentren en los índices pares
3).- Mostrar el elemento mayor, sólo 1 en caso de repetirse.
4).- Mostrar el índice (posición) del elemento mayor.
5).- Mostrar el elemento menor.
6).- Mostrar el índice del elemento menor.
7).- Crear un Vector de tamaño 10 que almacene nombres de personas.
8).- Crear un menú con las opciones:
            1) Agregar persona
            2)Ver Persona
Donde agregar permita ingresar el nombre de una persona por pantalla mientras el vector no esté
completo.
Ver persona permite ver el nombre del índice ingresado por pantalla.
